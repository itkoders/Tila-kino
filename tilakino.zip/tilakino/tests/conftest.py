import json, os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["TILAKINO_NO_BOOT"] = "1"
os.environ["TELEGRAM_BOT_TOKEN"] = "123:TESTTOKEN"
os.environ["WEBHOOK_SECRET"] = "hooksecret"
os.environ["ADMIN_ID"] = "6359925487"
os.environ["PAYMENT_CALLBACK_SECRET"] = "paysecret"
os.environ["CRON_SECRET"] = "cronsecret"
os.environ["RENDER_EXTERNAL_URL"] = "https://tilakino-telegram-bot.onrender.com"
os.environ["BOT_USERNAME"] = "tilakino_bot"
import pytest

ADMIN = 6359925487


class FakeResp:
    def __init__(self, j): self._j, self.status_code = j, 200
    def json(self): return self._j


class FakeTG:
    def __init__(self):
        self.calls, self.fail, self.mid = [], {}, 100
    def post(self, url, data, timeout=20):
        method = url.rsplit("/", 1)[1]
        params = {k: (json.loads(v) if k == "reply_markup" else v) for k, v in data.items()}
        self.calls.append((method, params))
        if method in self.fail:
            return FakeResp(self.fail[method])
        self.mid += 1
        return FakeResp({"ok": True, "result": {"message_id": self.mid, "username": "tilakino_bot"} if method != "getFile" else {"file_path": "p/x.jpg"}})
    def of(self, method, chat=None):
        return [p for m, p in self.calls if m == method and (chat is None or str(p.get("chat_id")) == str(chat))]
    def texts(self, chat=None):
        return [p.get("text") or p.get("caption") or "" for m, p in self.calls
                if m in ("sendMessage", "sendPhoto", "editMessageText", "sendVideo") and (chat is None or str(p.get("chat_id")) == str(chat))]
    def buttons(self):
        out = []
        for m, p in self.calls:
            rm = p.get("reply_markup")
            if rm and "inline_keyboard" in rm:
                out += [b for r in rm["inline_keyboard"] for b in r]
        return out


@pytest.fixture
def env(tmp_path, monkeypatch):
    import db, tg, ui, admin, services as sv
    from config import cfg
    cfg.reload()
    cfg.database_url = "sqlite:///" + str(tmp_path / "t.db")
    db.init(); db.init_schema()
    fake = FakeTG()
    monkeypatch.setattr(tg, "_post", fake.post)
    monkeypatch.setattr(tg, "sleep", lambda s: None)
    monkeypatch.setattr(ui, "sleep", lambda s: None)
    monkeypatch.setattr(admin, "sleep", lambda s: None)
    monkeypatch.setattr(admin, "BROADCAST_THREAD", False)
    return fake


@pytest.fixture
def client(env):
    import app as appmod
    a = appmod.create_app(); a.testing = True
    return a.test_client()


_uid = [1000]
def msg(uid, text=None, **extra):
    m = {"message_id": 1, "chat": {"id": uid, "type": "private"}, "from": {"id": uid, "first_name": "U%d" % uid, "language_code": "uz"}}
    if text is not None: m["text"] = text
    m.update(extra)
    return {"update_id": _next(), "message": m}

def cb(uid, data, message_id=50, has_photo=False):
    m = {"message_id": message_id, "chat": {"id": uid, "type": "private"}, "text": "x"}
    return {"update_id": _next(), "callback_query": {"id": "cb%d" % _next(), "from": {"id": uid, "first_name": "U%d" % uid}, "message": m, "data": data}}

_n = [0]
def _next():
    _n[0] += 1; return _n[0]
