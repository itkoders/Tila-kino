import hashlib, hmac, json, time
import pytest
from conftest import ADMIN, msg, cb
import db, handlers, services as sv, scheduler, tg, admin, ui
from config import cfg

U = 2001


def send(upd): handlers.handle_update(upd)


def mk(code="1234", title="Test Kino", **kw):
    return sv.create_movie({"code": code, "title": title, **kw})


# ---------- konfiguratsiya / ilova ----------
def test_app_starts_and_health(client):
    r = client.get("/health"); assert r.status_code == 200 and r.json["db"] is True

def test_missing_config_reported(monkeypatch, env):
    monkeypatch.setattr(cfg, "token", "")
    assert any("TELEGRAM_BOT_TOKEN" in p for p in cfg.problems())

def test_webhook_rejects_bad_secret(client):
    r = client.post("/webhook", json=msg(U, "/start"), headers={"X-Telegram-Bot-Api-Secret-Token": "bad"})
    assert r.status_code == 403
    assert client.post("/webhook", json=msg(U, "/start")).status_code == 403

def test_webhook_malformed(client):
    h = {"X-Telegram-Bot-Api-Secret-Token": "hooksecret"}
    assert client.post("/webhook", data="not json", headers=h).status_code == 400
    assert client.post("/webhook", json={"x": 1}, headers=h).status_code == 400

def test_webhook_duplicate_update(client, env):
    h = {"X-Telegram-Bot-Api-Secret-Token": "hooksecret"}
    u = msg(U, "/start")
    assert client.post("/webhook", json=u, headers=h).json == {"ok": True}
    n = len(env.calls)
    assert client.post("/webhook", json=u, headers=h).json.get("duplicate") is True
    assert len(env.calls) == n

def test_webhook_unconfigured_503(client, monkeypatch):
    monkeypatch.setattr(cfg, "webhook_secret", "")
    assert client.post("/webhook", json=msg(U, "x")).status_code == 503

def test_register_webhook_uses_render_url(env):
    import app
    assert app.register_webhook() is True
    c = env.of("setWebhook")[0]
    assert c["url"] == "https://tilakino-telegram-bot.onrender.com/webhook" and c["secret_token"] == "hooksecret"

def test_token_not_leaked_on_network_error(monkeypatch, env):
    import requests
    def boom(*a, **k): raise requests.ConnectionError("https://api.telegram.org/bot123:TESTTOKEN/x")
    monkeypatch.setattr(tg, "_post", boom)
    with pytest.raises(tg.TgError) as e: tg.send_message(1, "x")
    assert "TESTTOKEN" not in str(e.value) and e.value.__cause__ is None

# ---------- /start, menyu, animatsiya ----------
def test_start_menu_and_animation(env):
    send(msg(U, "/start"))
    assert env.of("editMessageText", U), "animatsiya kadrlari tahrirlanishi kerak"
    assert env.of("deleteMessage", U)
    kb = [p for p in env.of("sendMessage", U) if "keyboard" in (p.get("reply_markup") or {})][0]["reply_markup"]["keyboard"]
    labels = [b["text"] for r in kb for b in r]
    for want in ["🎬 Kinolar", "🔎 Kino qidirish", "🔢 Kod orqali topish", "📺 Seriallar", "❤️ Sevimlilar",
                 "💎 Premium sotib olish", "👤 Mening profilim", "📊 Obuna muddati va tomosha tarixi"]:
        assert want in labels

def test_animation_can_be_disabled(env, monkeypatch):
    monkeypatch.setattr(cfg, "animations", False)
    send(msg(U, "/start"))
    assert not env.of("editMessageText", U)

def test_unknown_command_and_input(env):
    send(msg(U, "/start")); env.calls.clear()
    send(msg(U, "/zzz")); send(msg(U, "qwertyuiop"))
    assert any("Tushunmadim" in t for t in env.texts(U)) and any("Hech narsa" in t for t in env.texts(U))

def test_multilang_labels(env):
    send(msg(U, "/start")); sv.set_lang(U, "ru"); env.calls.clear()
    send(msg(U, "🔢 Поиск по коду"))
    assert "Отправьте код" in env.texts(U)[0]

# ---------- qidiruv ----------
def test_search_title_and_code(env):
    mk("1234", "Qorong'u Qal'a"); mk("77", "Boshqa")
    assert [m["code"] for m in sv.search_catalog("qal'a")[0]] == ["1234"]
    assert [m["code"] for m in sv.search_catalog("77")[0]] == ["77"]
    send(msg(U, "/start")); env.calls.clear()
    send(msg(U, "1234"))
    assert any("Qorong" in t for t in env.texts(U))
    send(msg(U, "🔢 Kod orqali topish")); send(msg(U, "999"))
    assert any("Hech narsa" in t for t in env.texts(U))

def test_search_like_wildcards_escaped(env):
    mk("1", "100% Haqiqat"); mk("2", "Boshqa")
    assert sv.search_catalog("%")[1] == 1 and sv.search_catalog("_")[1] == 0

def test_unpublished_hidden(env):
    m = mk("5", "Yashirin"); sv.set_published(m["id"], False)
    assert sv.search_catalog("yashirin")[1] == 0 and sv.get_movie_by_code("5") is None

def test_newest_first(env, monkeypatch):
    t = [1000]; monkeypatch.setattr(sv, "now", lambda: t[0])
    mk("1", "Eski"); t[0] = 2000; mk("2", "Yangi")
    assert [m["code"] for m in sv.list_catalog("movie")[0]] == ["2", "1"]

def test_duplicate_code_rejected(env):
    mk("1234")
    with pytest.raises(ValueError, match="code_taken"): mk("1234", "Boshqa")
    with pytest.raises(ValueError): mk("abc", "x")

# ---------- seriallar ----------
def test_series_episode_search_and_nav(env):
    s = sv.create_movie({"code": "900", "title": "Serial", "kind": "series"})
    e1 = sv.create_episode(s["id"], 1, 1, "Boshlanish"); e2 = sv.create_episode(s["id"], 1, 2, "Davomi")
    with pytest.raises(ValueError, match="episode_exists"): sv.create_episode(s["id"], 1, 1)
    assert sv.search_catalog("davomi")[1] == 1 and sv.search_catalog("S1E2")[1] == 1
    assert sv.episode_neighbors(e1["id"]) == (None, e2["id"]) and sv.episode_neighbors(e2["id"]) == (e1["id"], None)
    send(msg(U, "/start")); env.calls.clear()
    send(cb(U, f"e:{s['id']}:0:0"))
    assert any("S1E2" in b["text"] for b in env.buttons())
    send(cb(U, f"ep:{e1['id']}"))
    assert any(b.get("callback_data") == f"ep:{e2['id']}" for b in env.buttons())

def test_episode_edit_and_reorder(env):
    s = sv.create_movie({"code": "9", "title": "S", "kind": "series"})
    e = sv.create_episode(s["id"], 1, 1)
    sv.update_episode(e["id"], "number", "5"); assert sv.get_episode(e["id"])["number"] == 5
    sv.set_episode_published(e["id"], False); assert sv.list_episodes(s["id"]) == []
    assert sv.delete_episode(e["id"])

# ---------- video va sifat ----------
def test_quality_resolution(env):
    m = mk()
    sv.set_variant("medium", movie_id=m["id"], file_id="MED", ftype="video")
    r = sv.resolve_variant(sv.list_variants(movie_id=m["id"]), False); assert r["variant"]["file_id"] == "MED"
    r = sv.resolve_variant(sv.list_variants(movie_id=m["id"]), True)
    assert r["variant"] is None and r["alternative"]["file_id"] == "MED"
    sv.set_variant("high", movie_id=m["id"], file_id="HIGH", ftype="video")
    assert sv.resolve_variant(sv.list_variants(movie_id=m["id"]), True)["variant"]["file_id"] == "HIGH"
    assert sv.resolve_variant(sv.list_variants(movie_id=m["id"]), False)["variant"]["file_id"] == "MED"

def test_high_only_requires_premium(env):
    m = mk(); sv.set_variant("high", movie_id=m["id"], file_id="H", ftype="video")
    send(msg(U, "/start")); env.calls.clear()
    send(cb(U, f"w:{m['id']}"))
    assert any("Premium" in t for t in env.texts(U)) and not env.of("sendVideo")

def test_watch_delivers_video_and_records_history(env):
    m = mk(); sv.set_variant("medium", movie_id=m["id"], file_id="MED", ftype="video")
    send(msg(U, "/start")); env.calls.clear()
    send(cb(U, f"w:{m['id']}"))
    assert env.of("sendVideo", U)[0]["video"] == "MED"
    assert env.of("editMessageText", U), "yuklash animatsiyasi"
    assert sv.get_movie(m["id"])["views"] == 1 and sv.list_history(U)[0]["code"] == "1234"

def test_no_video_not_claimed(env):
    m = mk(); send(msg(U, "/start")); env.calls.clear()
    send(cb(U, f"m:{m['id']}"))
    assert not any(b.get("callback_data", "").startswith("w:") for b in env.buttons())
    send(cb(U, f"w:{m['id']}")); assert any("qo'shilmagan" in t for t in env.texts(U))

def test_telegram_failure_on_video_graceful(env):
    m = mk(); sv.set_variant("medium", movie_id=m["id"], file_id="BAD", ftype="video")
    send(msg(U, "/start"))
    env.fail["sendVideo"] = {"ok": False, "error_code": 400, "description": "wrong file id"}
    send(cb(U, f"w:{m['id']}"))
    assert sv.get_movie(m["id"])["views"] == 0 and any("yuborib bo'lmadi" in t for t in env.texts(U))

def test_external_url_must_be_https(env):
    m = mk()
    with pytest.raises(ValueError): sv.set_variant("medium", movie_id=m["id"], external_url="http://x.com/a.mp4")

# ---------- sevimlilar ----------
def test_favorites_persist(env):
    m = mk(); send(msg(U, "/start"))
    send(cb(U, f"fav:{m['id']}")); assert sv.is_favorite(U, m["id"])
    assert [x["id"] for x in sv.list_favorites(U)[0]] == [m["id"]]
    send(cb(U, f"fav:{m['id']}")); assert not sv.is_favorite(U, m["id"])

# ---------- admin avtorizatsiya ----------
def test_admin_numeric_id_only(env):
    assert sv.is_admin(ADMIN) and not sv.is_admin(U)
    send(msg(U, "/start")); env.calls.clear()
    send(msg(U, "/admin")); assert any("ruxsat yo'q" in t for t in env.texts(U))
    send(msg(U, "/admin 6359925487"))
    assert not any("Admin panel" in t for t in env.texts(U))
    send(cb(U, "a:mov")); assert not any("Kino va seriallar" in t for t in env.texts(U))

def test_admin_panel_opens_for_owner(env):
    send(msg(ADMIN, "/start")); env.calls.clear()
    send(msg(ADMIN, "/admin")); assert any("Admin panel" in t for t in env.texts(ADMIN))

def test_user_cannot_run_admin_state(env):
    send(msg(U, "/start")); sv.set_state(U, "addm", {"kind": "movie", "i": 0, "v": {}})
    send(msg(U, "1234")); assert sv.get_movie_by_code("1234", False) is None

def test_user_cannot_approve_payment(env):
    send(msg(U, "/start")); p = sv.create_payment(U, "1m")
    send(cb(U, f"pay:ok:{p['id']}")); assert sv.get_payment(p["id"])["status"] == "pending"

# ---------- admin: kino/serial yaratish va tahrirlash (wizard) ----------
def test_admin_wizard_creates_movie(env):
    send(msg(ADMIN, "/start")); send(cb(ADMIN, "a:addm:movie"))
    for x in ["555", "Wizard Kino", "2021", "Uzbekiston", "Drama", "uz,ru", "Tavsif", "8.5"]:
        send(msg(ADMIN, x))
    send(msg(ADMIN, "", photo=[{"file_id": "P1"}]))
    m = sv.get_movie_by_code("555")
    assert m and m["title"] == "Wizard Kino" and m["year"] == 2021 and m["poster_file_id"] == "P1" and m["rating"] == 8.5

def test_admin_wizard_rejects_dup_code_and_bad_lang(env):
    mk("555"); send(msg(ADMIN, "/start")); send(cb(ADMIN, "a:addm:movie")); env.calls.clear()
    send(msg(ADMIN, "555")); assert any("band" in t for t in env.texts(ADMIN))
    send(msg(ADMIN, "556")); send(msg(ADMIN, "T")); send(msg(ADMIN, "2020")); send(msg(ADMIN, "-")); send(msg(ADMIN, "-"))
    send(msg(ADMIN, "klingon")); assert any("Til:" in t for t in env.texts(ADMIN))

def test_admin_edit_movie_and_video_upload(env):
    m = mk(); send(msg(ADMIN, "/start"))
    send(cb(ADMIN, f"a:me:{m['id']}:title")); send(msg(ADMIN, "Yangi nom"))
    assert sv.get_movie(m["id"])["title"] == "Yangi nom"
    send(cb(ADMIN, f"a:mv:{m['id']}:high")); send(msg(ADMIN, None, video={"file_id": "VID9"}))
    assert sv.list_variants(movie_id=m["id"])[0]["file_id"] == "VID9"
    send(cb(ADMIN, f"a:ml:{m['id']}:medium")); send(msg(ADMIN, "https://cdn.example.com/a.mp4"))
    assert sv.web_variant(movie_id=m["id"])["external_url"] == "https://cdn.example.com/a.mp4"

def test_admin_series_episode_wizard(env):
    s = sv.create_movie({"code": "8", "title": "S", "kind": "series"}); send(msg(ADMIN, "/start"))
    send(cb(ADMIN, f"a:ep:{s['id']}"))
    for x in ["1", "3", "Uchinchi", "-"]: send(msg(ADMIN, x))
    e = sv.list_episodes(s["id"])[0]; assert (e["season"], e["number"], e["title"], e["description"]) == (1, 3, "Uchinchi", None)

def test_delete_requires_confirmation(env):
    m = mk(); send(msg(ADMIN, "/start"))
    send(cb(ADMIN, f"a:md:{m['id']}")); assert sv.get_movie(m["id"]) is not None
    send(cb(ADMIN, f"a:do:dm:{m['id']}")); assert sv.get_movie(m["id"]) is None
    assert any(r["action"] == "movie_delete" for r in sv.recent_audit())

def test_unpublish_toggle(env):
    m = mk(); send(msg(ADMIN, "/start")); send(cb(ADMIN, f"a:mt:{m['id']}"))
    assert sv.get_movie(m["id"])["published"] == 0

# ---------- Premium / to'lovlar ----------
def test_default_prices_and_admin_change(env):
    p = sv.get_plans(); assert [p[k]["price"] for k in ("1m", "2m", "6m", "1y")] == [10000, 20000, 40000, 60000]
    send(msg(ADMIN, "/start")); send(cb(ADMIN, "a:ppe:1m:price")); send(msg(ADMIN, "12000"))
    assert sv.get_plans()["1m"]["price"] == 12000
    with pytest.raises(ValueError): sv.update_plan("1m", "price", "-5")

def test_payment_state_transitions(env):
    send(msg(U, "/start")); p = sv.create_payment(U, "1m")
    assert sv.create_payment(U, "1m")["id"] == p["id"]  # takroriy so'rov yangi yaratmaydi
    ok, _ = sv.decide_payment(p["id"], True, ADMIN); assert ok
    ok, q = sv.decide_payment(p["id"], True, ADMIN); assert not ok
    ok, q = sv.decide_payment(p["id"], False, ADMIN); assert not ok and q["status"] == "approved"
    assert len(sv.list_subscriptions(U)) == 1   # ikki marta faollashmadi
    assert sv.get_user(U)["premium_until"] > sv.now() + 29 * 86400

def test_manual_payment_flow_end_to_end(env):
    sv.set_setting("card_info", "8600 1234 5678 9012")
    send(msg(U, "/start")); send(cb(U, "buy:2m"))
    assert any("8600" in t for t in env.texts(U))
    env.calls.clear(); send(msg(U, None, photo=[{"file_id": "CHK"}]))
    assert env.of("sendPhoto", ADMIN)
    pid = sv.list_payments(uid=U)[0]["id"]
    send(cb(ADMIN, f"pay:ok:{pid}"))
    assert sv.is_premium(sv.get_user(U)) and any("tasdiqlandi" in t for t in env.texts(U))
    env.calls.clear(); send(cb(ADMIN, f"pay:ok:{pid}"))   # takroriy bosish
    assert len(sv.list_subscriptions(U)) == 1

def test_screenshot_alone_not_premium(env):
    sv.set_setting("card_info", "x"); send(msg(U, "/start")); send(cb(U, "buy:1m")); send(msg(U, None, photo=[{"file_id": "C"}]))
    assert not sv.is_premium(sv.get_user(U))

def test_reject_notifies(env):
    send(msg(U, "/start")); p = sv.create_payment(U, "1m"); env.calls.clear()
    send(cb(ADMIN, f"pay:no:{p['id']}")); assert sv.get_payment(p["id"])["status"] == "rejected"
    assert any("rad etildi" in t for t in env.texts(U)) and not sv.is_premium(sv.get_user(U))

def _sig(body): return hmac.new(b"paysecret", body, hashlib.sha256).hexdigest()

def test_auto_payment_callback_signature_amount_duplicates(client, env):
    send(msg(U, "/start")); p = sv.create_payment(U, "1m")
    body = json.dumps({"reference": p["reference"], "amount": 10000, "txn_id": "T1"}).encode()
    assert client.post("/payments/callback/generic", data=body, headers={"X-Signature": "bad"}).status_code == 403
    bad_amt = json.dumps({"reference": p["reference"], "amount": 1, "txn_id": "T0"}).encode()
    assert client.post("/payments/callback/generic", data=bad_amt, headers={"X-Signature": _sig(bad_amt)}).status_code == 422
    assert sv.get_payment(p["id"])["status"] == "pending"
    assert client.post("/payments/callback/generic", data=body, headers={"X-Signature": _sig(body)}).json["status"] == "approved"
    assert client.post("/payments/callback/generic", data=body, headers={"X-Signature": _sig(body)}).json["status"] == "duplicate"
    assert len(sv.list_subscriptions(U)) == 1 and sv.is_premium(sv.get_user(U))

def test_payment_provider_unconfigured(client, monkeypatch):
    monkeypatch.setattr(cfg, "payment_secret", "")
    assert client.post("/payments/callback/generic", data=b"{}").status_code == 501
    assert client.post("/payments/callback/click", data=b"{}").status_code == 404

def test_manual_premium_grant_revoke_expiry(env):
    send(msg(U, "/start")); sv.grant_premium(U, 10)
    assert sv.is_premium(sv.get_user(U))
    sv.set_premium_expiry(U, sv.parse_local_date("2099-01-01")); assert sv.fmt_date(sv.get_user(U)["premium_until"]) == "2099-01-01"
    sv.revoke_premium(U); assert not sv.is_premium(sv.get_user(U))
    send(msg(ADMIN, "/start")); send(cb(ADMIN, "a:pg")); send(msg(ADMIN, f"{U} 5"))
    assert sv.is_premium(sv.get_user(U))

def test_stale_payments_expire(env, monkeypatch):
    send(msg(U, "/start")); p = sv.create_payment(U, "1m")
    monkeypatch.setattr(sv, "now", lambda: p["created_at"] + 25 * 3600)
    sv.expire_payments(); assert sv.get_payment(p["id"])["status"] == "expired"

# ---------- muddat tugashi va eslatmalar ----------
def test_expiry_and_reminders_no_duplicates(env, monkeypatch):
    send(msg(U, "/start")); base = 1_800_000_000
    monkeypatch.setattr(sv, "now", lambda: base)
    db.execute("UPDATE users SET premium_until=? WHERE id=?", (base + 3 * 86400, U))
    sent = []; r = scheduler.tick(lambda *a: sent.append(a)); assert [s[2] for s in sent] == ["remind3"]
    scheduler.tick(lambda *a: sent.append(a)); assert len(sent) == 1
    # tugash kuni
    monkeypatch.setattr(sv, "now", lambda: base + 3 * 86400 - 600)
    scheduler.tick(lambda *a: sent.append(a)); assert [s[2] for s in sent] == ["remind3", "remind0"]
    scheduler.tick(lambda *a: sent.append(a)); assert len(sent) == 2
    # tugagach pastlashtirildi
    monkeypatch.setattr(sv, "now", lambda: base + 4 * 86400)
    assert not sv.is_premium(sv.get_user(U))

def test_reminder_text_sent_via_telegram(env, monkeypatch):
    send(msg(U, "/start")); base = 1_800_000_000; monkeypatch.setattr(sv, "now", lambda: base)
    db.execute("UPDATE users SET premium_until=? WHERE id=?", (base + 2 * 86400, U)); env.calls.clear()
    scheduler.tick(handlers.send_reminder); assert any("3 kundan" in t for t in env.texts(U))

def test_cron_endpoint_secret(client):
    assert client.get("/cron/tick").status_code == 403
    assert client.get("/cron/tick?key=cronsecret").status_code == 200

def test_dates_use_tashkent():
    assert sv.fmt_dt(1_800_000_000) == "2027-01-15 13:00"  # 08:00 UTC + 5 soat

# ---------- homiy / Premium reklamasiz ----------
def test_sponsor_not_for_premium_and_no_forced_channels(env):
    sv.add_sponsor("Reklama matni", "https://example.com")
    send(msg(U, "/start")); env.calls.clear(); send(msg(U, "🎬 Kinolar"))
    assert any("Reklama matni" in t for t in env.texts(U))
    sv.grant_premium(U, 5); db.execute("UPDATE users SET last_sponsor_at=0 WHERE id=?", (U,)); env.calls.clear()
    send(msg(U, "🎬 Kinolar")); assert not any("Reklama matni" in t for t in env.texts(U))
    assert not env.of("getChatMember")

def test_no_daily_limit(env):
    for i in range(6): mk(str(i + 1), f"K{i}"); 
    send(msg(U, "/start")); env.calls.clear()
    for i in range(6): send(msg(U, str(i + 1)))
    assert sum(1 for t in env.texts(U) if "K" in t and "🔢" in t) == 6

# ---------- foydalanuvchilar / bloklash ----------
def test_block_user(env):
    send(msg(U, "/start")); send(msg(ADMIN, "/start")); send(cb(ADMIN, f"a:ub:{U}"))
    env.calls.clear(); send(msg(U, "/start")); assert any("chetlatilgansiz" in t for t in env.texts(U))
    with pytest.raises(ValueError): sv.set_blocked(ADMIN, True)

def test_referral_bonus_once(env):
    send(msg(U, "/start")); sv.set_setting("ref_bonus_days", "3")
    send(msg(3001, f"/start {U}")); send(msg(3001, f"/start {U}"))
    assert sv.get_user(U)["ref_count"] == 1 and sv.is_premium(sv.get_user(U))
    send(msg(3002, "/start 3002")); assert sv.get_user(3002)["referrer_id"] is None

# ---------- yordamchi adminlar ----------
def test_helper_admin_roles(env):
    send(msg(U, "/start"))
    with pytest.raises(PermissionError): sv.add_helper(U, 5, ["catalog"])
    sv.add_helper(ADMIN, U, ["catalog"])
    assert sv.is_admin(U) and sv.has_perm(U, "catalog") and not sv.has_perm(U, "premium")
    send(cb(U, "a:prem")); assert not any("Premium boshqaruvi" in t for t in env.texts(U))
    send(cb(U, "a:hlp")); assert not any("Yordamchi adminlar" in t for t in env.texts(U))
    with pytest.raises(ValueError): sv.remove_helper(ADMIN, ADMIN)
    with pytest.raises(PermissionError): sv.remove_helper(U, ADMIN)
    assert sv.is_owner(ADMIN) and sv.remove_helper(ADMIN, U) and not sv.is_admin(U)

def test_helper_added_via_panel(env):
    send(msg(ADMIN, "/start")); send(cb(ADMIN, "a:hla")); send(msg(ADMIN, "4444 catalog,stats"))
    assert sv.has_perm(4444, "stats")

# ---------- statistika ----------
def test_stats(env):
    m = mk(); send(msg(U, "/start")); sv.set_variant("medium", movie_id=m["id"], file_id="F", ftype="video")
    send(cb(U, f"w:{m['id']}")); p = sv.create_payment(U, "1m"); sv.decide_payment(p["id"], True, ADMIN)
    s = sv.stats(); assert s["users"] == 1 and s["views"] == 1 and s["revenue"] == 10000 and s["premium_active"] == 1
    send(msg(ADMIN, "/start")); env.calls.clear(); send(cb(ADMIN, "a:st")); assert any("Statistika" in t for t in env.texts(ADMIN))

# ---------- broadcast ----------
def test_broadcast_preview_confirm_report(env):
    for u in (11, 12, 13): send(msg(u, "/start"))
    send(msg(ADMIN, "/start")); send(cb(ADMIN, "a:bc")); env.calls.clear()
    send(msg(ADMIN, "Salom hammaga"))
    assert env.of("copyMessage", ADMIN) and not env.of("copyMessage", 11)   # faqat ko'rib chiqish
    bid = db.one("SELECT id FROM broadcasts")["id"]
    env.fail["copyMessage"] = None; del env.fail["copyMessage"]
    orig = env.post
    def flaky(url, data, timeout=20):
        if url.endswith("copyMessage") and data["chat_id"] == 12:
            env.calls.append(("copyMessage", dict(data))); return type(env.post(url, {}, 0))({"ok": False, "error_code": 403, "description": "blocked"})
        return orig(url, data, timeout)
    import tg as _tg; _tg._post = flaky
    send(cb(ADMIN, f"a:bcok:{bid}"))
    b = sv.get_broadcast(bid); assert (b["sent"], b["skipped"], b["status"]) == (3, 1, "done")
    assert sv.get_user(12)["bot_blocked"] == 1 and 12 not in sv.eligible_user_ids()
    send(cb(ADMIN, f"a:bcok:{bid}"))                     # ikkinchi marta yuborilmaydi
    assert sv.get_broadcast(bid)["sent"] == b["sent"]

def test_broadcast_retries_on_429(env):
    send(msg(21, "/start")); send(msg(ADMIN, "/start")); send(cb(ADMIN, "a:bc")); send(msg(ADMIN, "x"))
    bid = db.one("SELECT id FROM broadcasts")["id"]; orig = env.post; hits = []
    def once(url, data, timeout=20):
        if url.endswith("copyMessage") and data["chat_id"] == 21 and not hits:
            hits.append(1); env.calls.append(("copyMessage", dict(data)))
            return type(orig(url, {}, 0))({"ok": False, "error_code": 429, "description": "slow", "parameters": {"retry_after": 1}})
        return orig(url, data, timeout)
    import tg as _tg; _tg._post = once
    send(cb(ADMIN, f"a:bcok:{bid}")); assert sv.get_broadcast(bid)["sent"] >= 1

# ---------- xatolarga chidamlilik ----------
def test_blocked_by_user_marks_flag(env):
    env.fail["sendMessage"] = {"ok": False, "error_code": 403, "description": "bot was blocked"}
    send(msg(U, "/start")); assert sv.get_user(U)["bot_blocked"] == 1

def test_db_error_on_webhook_returns_503(client, monkeypatch):
    monkeypatch.setattr(sv, "claim_update", lambda i: (_ for _ in ()).throw(RuntimeError("db down")))
    r = client.post("/webhook", json=msg(U, "/start"), headers={"X-Telegram-Bot-Api-Secret-Token": "hooksecret"})
    assert r.status_code == 503

def test_handler_exception_does_not_crash_webhook(client, monkeypatch):
    monkeypatch.setattr(handlers, "handle_update", lambda u: 1 / 0)
    r = client.post("/webhook", json=msg(U, "/start"), headers={"X-Telegram-Bot-Api-Secret-Token": "hooksecret"})
    assert r.status_code == 200

def test_bad_callback_data_graceful(env):
    send(msg(U, "/start"))
    for d in ["m:abc", "e:1", "zzz", "w:999999", "a:nope", "lang:xx", "buy:zz"]: send(cb(U, d))

def test_edit_not_modified_ignored(env):
    m = mk(); send(msg(U, "/start"))
    env.fail["editMessageText"] = {"ok": False, "error_code": 400, "description": "message is not modified"}
    send(cb(U, "menu"))

# ---------- sayt ----------
def test_website_pages_and_api(client, env):
    m = mk("42", "Sayt Kino", poster_file_id="PF"); sv.set_variant("medium", movie_id=m["id"], external_url="https://cdn.example.com/v.mp4")
    sv.set_variant("high", movie_id=m["id"], external_url="https://cdn.example.com/HIGH.mp4")
    r = client.get("/"); assert r.status_code == 200 and b"Sayt Kino" in r.data and b"@keyframes rise" in r.data
    r = client.get("/movie/42"); assert b"<video" in r.data and b"v.mp4" in r.data and b"HIGH.mp4" not in r.data
    assert client.get("/api/movie/42").json["watch_url"] == "https://cdn.example.com/v.mp4"
    assert client.get("/api/catalog?q=sayt").json["total"] == 1
    assert client.get("/movie/nope").status_code == 404 and client.get("/api/movie/nope").status_code == 404
    assert b"TESTTOKEN" not in client.get("/").data and b"TESTTOKEN" not in client.get("/api/catalog").data

def test_website_series_and_poster_proxy(client, env, monkeypatch):
    import app as a
    s = sv.create_movie({"code": "7", "title": "Serial", "kind": "series", "poster_file_id": "PF"})
    e = sv.create_episode(s["id"], 1, 1, "Bir"); sv.set_variant("medium", episode_id=e["id"], external_url="https://v.example.com/e1.mp4")
    assert b"e1.mp4" in client.get("/movie/7").data
    monkeypatch.setattr(a, "fetch_poster", lambda f: (b"IMG", "image/jpeg"))
    r = client.get("/poster/7"); assert r.data == b"IMG" and r.mimetype == "image/jpeg"
    monkeypatch.setattr(a, "fetch_poster", lambda f: 1 / 0); assert client.get("/poster/7").status_code == 404

def test_site_hides_unpublished(client, env):
    m = mk("43", "Yashirin Kino"); sv.set_published(m["id"], False)
    assert client.get("/movie/43").status_code == 404 and b"Yashirin" not in client.get("/").data

def test_tashkent_midnight_expiry_date():
    assert sv.fmt_date(sv.parse_local_date("2026-12-31")) == "2026-12-31"
